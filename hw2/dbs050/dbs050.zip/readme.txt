Valen Johnson 1617464

All tests, other than invalid input checking, were done fine locally